﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace viteMonLogement
{
   
    public class CL_user
    {
        public static CL_user userReg1;
        private string login;
        private int idType;
        private int id;
        private string nom;
        private string prenom;
        private string idLogement;
        private string mail;
        private DateTime DateNaissance;
        private string adresse;
        private string CP;
        private string ville;
        private string Telephone;

        
        public CL_user(string unLogin,int unIDtype,int unId,string unNom,string unPrenom,string unMail,DateTime uneDate, string uneAdresse, string unCP, string uneVille, string unTel)
        {
            login = unLogin;
            idType = unIDtype;
            id = unId;
            nom = unNom;
            prenom = unPrenom;
            idLogement = "" ;
            mail = unMail;
            DateNaissance = uneDate;
            adresse = uneAdresse;
            CP = unCP;
            ville = uneVille;
            Telephone = unTel;
        }
        public void destrucUser(){ CL_user.userReg1=null; }
        public string getLogin() { return login; }
        public int getIdType() { return idType;}
        public int getId() { return id;}
        public string getNom() { return nom;}
        public string getPrenom() { return prenom;}
        public string getIdLogement() { return idLogement;}
        public string getMail() { return mail;}
        public DateTime getDateNaissance() { return DateNaissance; }
        public string getAdresse() { return adresse;}
        public string getVille() { return ville;}
        public string getCp() { return CP; }
        public string getTelephone() { return Telephone;}
        public void setIdLogement(string unid) { idLogement = unid;}

    }
}
