﻿namespace viteMonLogement
{
    partial class Connexion
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.PRI_PN_LOGIN = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.PRI_PN_LOG_TXT_USER = new System.Windows.Forms.TextBox();
            this.PRI_PN_LOG_TXT_PASSWORD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PRI_PN_LOGIN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PRI_PN_LOGIN
            // 
            this.PRI_PN_LOGIN.BackColor = System.Drawing.Color.White;
            this.PRI_PN_LOGIN.Controls.Add(this.pictureBox4);
            this.PRI_PN_LOGIN.Controls.Add(this.pictureBox5);
            this.PRI_PN_LOGIN.Controls.Add(this.PRI_PN_LOG_TXT_USER);
            this.PRI_PN_LOGIN.Controls.Add(this.PRI_PN_LOG_TXT_PASSWORD);
            this.PRI_PN_LOGIN.Controls.Add(this.label3);
            this.PRI_PN_LOGIN.Controls.Add(this.label1);
            this.PRI_PN_LOGIN.Controls.Add(this.panel2);
            this.PRI_PN_LOGIN.Controls.Add(this.panel1);
            this.PRI_PN_LOGIN.Controls.Add(this.pictureBox2);
            this.PRI_PN_LOGIN.Controls.Add(this.pictureBox3);
            this.PRI_PN_LOGIN.Controls.Add(this.label2);
            this.PRI_PN_LOGIN.Controls.Add(this.button1);
            this.PRI_PN_LOGIN.Controls.Add(this.pictureBox1);
            this.PRI_PN_LOGIN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PRI_PN_LOGIN.Location = new System.Drawing.Point(0, 0);
            this.PRI_PN_LOGIN.Name = "PRI_PN_LOGIN";
            this.PRI_PN_LOGIN.Size = new System.Drawing.Size(290, 439);
            this.PRI_PN_LOGIN.TabIndex = 0;
            this.PRI_PN_LOGIN.Paint += new System.Windows.Forms.PaintEventHandler(this.PRI_PN_LOGIN_Paint);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::viteMonLogement.Properties.Resources.icons8_eye_unchecked_50;
            this.pictureBox4.Location = new System.Drawing.Point(224, 261);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 35);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::viteMonLogement.Properties.Resources.icons8_eye_checked_50;
            this.pictureBox5.Location = new System.Drawing.Point(224, 261);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 35);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // PRI_PN_LOG_TXT_USER
            // 
            this.PRI_PN_LOG_TXT_USER.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PRI_PN_LOG_TXT_USER.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRI_PN_LOG_TXT_USER.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.PRI_PN_LOG_TXT_USER.Location = new System.Drawing.Point(54, 194);
            this.PRI_PN_LOG_TXT_USER.Multiline = true;
            this.PRI_PN_LOG_TXT_USER.Name = "PRI_PN_LOG_TXT_USER";
            this.PRI_PN_LOG_TXT_USER.Size = new System.Drawing.Size(204, 24);
            this.PRI_PN_LOG_TXT_USER.TabIndex = 11;
            // 
            // PRI_PN_LOG_TXT_PASSWORD
            // 
            this.PRI_PN_LOG_TXT_PASSWORD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PRI_PN_LOG_TXT_PASSWORD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRI_PN_LOG_TXT_PASSWORD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.PRI_PN_LOG_TXT_PASSWORD.Location = new System.Drawing.Point(54, 269);
            this.PRI_PN_LOG_TXT_PASSWORD.Multiline = true;
            this.PRI_PN_LOG_TXT_PASSWORD.Name = "PRI_PN_LOG_TXT_PASSWORD";
            this.PRI_PN_LOG_TXT_PASSWORD.PasswordChar = '*';
            this.PRI_PN_LOG_TXT_PASSWORD.Size = new System.Drawing.Size(204, 24);
            this.PRI_PN_LOG_TXT_PASSWORD.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.label3.Location = new System.Drawing.Point(115, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Exit";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.label1.Location = new System.Drawing.Point(158, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Clear Field";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.panel2.Location = new System.Drawing.Point(23, 295);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(236, 1);
            this.panel2.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.panel1.Location = new System.Drawing.Point(23, 220);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 1);
            this.panel1.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::viteMonLogement.Properties.Resources.icons8_lock_48;
            this.pictureBox2.Location = new System.Drawing.Point(23, 264);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(25, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::viteMonLogement.Properties.Resources.icons8_user_64;
            this.pictureBox3.Location = new System.Drawing.Point(23, 189);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(25, 25);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bauhaus 93", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.label2.Location = new System.Drawing.Point(72, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 45);
            this.label2.TabIndex = 6;
            this.label2.Text = "LOG IN";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(23, 334);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(236, 41);
            this.button1.TabIndex = 5;
            this.button1.Text = "Connexion";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::viteMonLogement.Properties.Resources.icons8_propriété_48;
            this.pictureBox1.Location = new System.Drawing.Point(80, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Connexion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 439);
            this.Controls.Add(this.PRI_PN_LOGIN);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Connexion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.PRI_PN_LOGIN.ResumeLayout(false);
            this.PRI_PN_LOGIN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PRI_PN_LOGIN;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PRI_PN_LOG_TXT_PASSWORD;
        private System.Windows.Forms.TextBox PRI_PN_LOG_TXT_USER;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
    }
}

