﻿using System;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace viteMonLogement
{
    public partial class userType1 : Form
    {
        public userType1()
        {
            InitializeComponent();
            UserTest.Text ="Bonjour "+CL_user.userReg1.getPrenom()+" "+CL_user.userReg1.getNom()+". Bienvenue sur ViteMonLogement !" ;
            int idloca = int.Parse(CL_user.userReg1.getId().ToString());
            String sqlLoc = "SELECT * FROM locataire WHERE ID_Locataire=" +idloca;
            CL_Bdd.Connexion_Bdd("Lecture", sqlLoc, "Execption Ligne 15 Loca");
            DataTable loca = CL_Bdd.DT;
            

            if (loca.Rows.Count!=0)
            {
               PRN_PN_MAIN_BUTTON_MON_LOGEMENT.BringToFront();
                CL_user.userReg1.setIdLogement(loca.Rows[0].ItemArray[1].ToString());
            }
            



        }

        private void UserTest_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PRN_PN_LOC_LOGEMENT.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CL_user.userReg1.destrucUser();
            this.Hide();
            new Connexion().Show();
        }

        private void PRN_PN_LOC_LOGEMENT_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PRN_PN_LOC_MAIN.BringToFront();
            
        }

        private void PRN_PN_MAIN_BUTTON_MON_LOGEMENT_Click(object sender, EventArgs e)
        {

            string sql3 = "SELECT * FROM appartement where id=" + CL_user.userReg1.getIdLogement();
            CL_Bdd.Connexion_Bdd("Lecture",sql3,"ca marche po");
            DataTable Appart = CL_Bdd.DT;
            if (Appart.Rows.Count!=0)
            {
                PRN_PN_LOC_MON_LOG.BringToFront();
                PRN_PN_LOC_MON_L_Lab1.Text ="Adresse:"+ CL_Bdd.DT.Rows[0].ItemArray[4].ToString() + " " + CL_Bdd.DT.Rows[0].ItemArray[5].ToString() + " " + CL_Bdd.DT.Rows[0].ItemArray[6].ToString();
                PRN_PN_LOC_MON_L_Lab3.Text ="Prix mensuel:"+ Appart.Rows[0].ItemArray[3].ToString() + "€";
                PRN_PN_LOC_MON_L_Lab2.Text ="Type habitation: "+ Appart.Rows[0].ItemArray[2].ToString();
                string sqlPhoto = "SELECT * FROM photo WHERE id_appart="+ CL_user.userReg1.getIdLogement();
                CL_Bdd.Connexion_Bdd("Lecture", sqlPhoto, "ca marche po");
                if (CL_Bdd.DT.Rows.Count != 0)
                {
                    //MessageBox.Show(@"C:\Users\maltl\source\repos\viteMonLogement\viteMonLogement\Photos\" + CL_Bdd.DT.Rows[0].ItemArray[0]);
                    PRN_PN_LOC_MON_LOG_PIC1.ImageLocation= @"C:\Users\maltl\source\repos\viteMonLogement\viteMonLogement\Photos\"+CL_Bdd.DT.Rows[0].ItemArray[1];
                }
            }
            else
            {
               
                MessageBox.Show("Erreur dsl frérot");
            }
            

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            PRN_PN_LOC_MAIN.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PRN_PN_LOC_MAIN.BringToFront();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void PRN_PN_MAIN_BUTTON_DOSSIER_Click(object sender, EventArgs e)
        {
            PRN_PN_LOC_DOSSIER.BringToFront();
            PRN_PN_LOC_DOSSIER_T1.Text = CL_user.userReg1.getNom();
            PRN_PN_LOC_DOSSIER_T2.Text = CL_user.userReg1.getPrenom();
            PRN_PN_LOC_DOSSIER_T3.Text = CL_user.userReg1.getMail();
            PRN_PN_LOC_DOSSIER_T4.Text = CL_user.userReg1.getAdresse();
            PRN_PN_LOC_DOSSIER_T5.Text = CL_user.userReg1.getCp();
            PRN_PN_LOC_DOSSIER_T6.Text = CL_user.userReg1.getVille();
            PRN_PN_LOC_DOSSIER_T7.Text = CL_user.userReg1.getTelephone();
            PRN_PN_LOC_DOSSIER_DATE1.Value = CL_user.userReg1.getDateNaissance();
        }

        private void propertyGrid1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;)|*.jpg;*.jpeg;.*.gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
            {
                PictureBox_Id_CARD.Image = new Bitmap(opnfd.FileName);
            }
        }

        private void PRN_PN_LOC_DOSSIER_B_SUB_Click(object sender, EventArgs e)
        {
            string sqlUserUp= "INSERT INTO utilisateur(nom,prenom,mail,adresse,cp,ville,telephone,DateNaissance) VALUES('"+ PRN_PN_LOC_DOSSIER_T1.Text+"',"+ PRN_PN_LOC_DOSSIER_T2.Text+"',"+ PRN_PN_LOC_DOSSIER_T3.Text+"',"+ PRN_PN_LOC_DOSSIER_T4.Text+"',"+ PRN_PN_LOC_DOSSIER_T5.Text+"',"+ PRN_PN_LOC_DOSSIER_T6.Text+"',"+ PRN_PN_LOC_DOSSIER_T7.Text+"'," + PRN_PN_LOC_DOSSIER_DATE1.Value+") WHERE id=" + CL_user.userReg1.getId();
           // CL_Bdd.Connexion_Bdd("")
        }
    }
}
