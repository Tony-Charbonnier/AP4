﻿namespace viteMonLogement
{
    partial class userType1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserTest = new System.Windows.Forms.Label();
            this.PRN_PN_MAIN_BUTTON_DOSSIER = new System.Windows.Forms.Button();
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS = new System.Windows.Forms.Button();
            this.PRN_PN_MAIN_BUTTON_DEMANDES = new System.Windows.Forms.Button();
            this.PRN_PN_MAIN_BUTTON_DEC = new System.Windows.Forms.Button();
            this.PRN_PN_LOC_MAIN = new System.Windows.Forms.Panel();
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT = new System.Windows.Forms.Button();
            this.PRN_PN_LOC_LOGEMENT = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.PRN_PN_LOC_MON_LOG = new System.Windows.Forms.Panel();
            this.PRN_PN_LOC_MON_LOG_PIC1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.PRN_PN_LOC_MON_L_Lab3 = new System.Windows.Forms.Label();
            this.PRN_PN_LOC_MON_L_Lab2 = new System.Windows.Forms.Label();
            this.PRN_PN_LOC_MON_L_Lab1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PRN_PN_LOC_DOSSIER_T1 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T2 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T5 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T7 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T3 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T4 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_T6 = new System.Windows.Forms.TextBox();
            this.PRN_PN_LOC_DOSSIER_DATE1 = new System.Windows.Forms.DateTimePicker();
            this.PRN_PN_LOC_DOSSIER = new System.Windows.Forms.Panel();
            this.BUTTON_ID_CARD = new System.Windows.Forms.Button();
            this.PictureBox_Id_CARD = new System.Windows.Forms.PictureBox();
            this.PRN_PN_LOC_DOSSIER_B_SUB = new System.Windows.Forms.Button();
            this.PRN_PN_LOC_MAIN.SuspendLayout();
            this.PRN_PN_LOC_LOGEMENT.SuspendLayout();
            this.PRN_PN_LOC_MON_LOG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PRN_PN_LOC_MON_LOG_PIC1)).BeginInit();
            this.PRN_PN_LOC_DOSSIER.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox_Id_CARD)).BeginInit();
            this.SuspendLayout();
            // 
            // UserTest
            // 
            this.UserTest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserTest.AutoSize = true;
            this.UserTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UserTest.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserTest.Location = new System.Drawing.Point(49, 161);
            this.UserTest.Name = "UserTest";
            this.UserTest.Size = new System.Drawing.Size(680, 36);
            this.UserTest.TabIndex = 0;
            this.UserTest.Text = "Bienvenue NOM + PRENOM sur viteMonLogement";
            this.UserTest.Click += new System.EventHandler(this.UserTest_Click);
            // 
            // PRN_PN_MAIN_BUTTON_DOSSIER
            // 
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.AutoSize = true;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.PRN_PN_MAIN_BUTTON_DOSSIER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold);
            this.PRN_PN_MAIN_BUTTON_DOSSIER.ForeColor = System.Drawing.Color.White;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Location = new System.Drawing.Point(598, 233);
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Name = "PRN_PN_MAIN_BUTTON_DOSSIER";
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Size = new System.Drawing.Size(210, 90);
            this.PRN_PN_MAIN_BUTTON_DOSSIER.TabIndex = 1;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Text = "Mon dossier";
            this.PRN_PN_MAIN_BUTTON_DOSSIER.UseVisualStyleBackColor = false;
            this.PRN_PN_MAIN_BUTTON_DOSSIER.Click += new System.EventHandler(this.PRN_PN_MAIN_BUTTON_DOSSIER_Click);
            // 
            // PRN_PN_MAIN_BUTTON_LOGEMENTS
            // 
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold);
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.ForeColor = System.Drawing.Color.White;
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Location = new System.Drawing.Point(49, 233);
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Name = "PRN_PN_MAIN_BUTTON_LOGEMENTS";
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Size = new System.Drawing.Size(210, 90);
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.TabIndex = 2;
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Text = "Voir les logements disponible";
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.UseVisualStyleBackColor = false;
            this.PRN_PN_MAIN_BUTTON_LOGEMENTS.Click += new System.EventHandler(this.button2_Click);
            // 
            // PRN_PN_MAIN_BUTTON_DEMANDES
            // 
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_MAIN_BUTTON_DEMANDES.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.PRN_PN_MAIN_BUTTON_DEMANDES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold);
            this.PRN_PN_MAIN_BUTTON_DEMANDES.ForeColor = System.Drawing.Color.White;
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Location = new System.Drawing.Point(333, 233);
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Name = "PRN_PN_MAIN_BUTTON_DEMANDES";
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Size = new System.Drawing.Size(210, 90);
            this.PRN_PN_MAIN_BUTTON_DEMANDES.TabIndex = 3;
            this.PRN_PN_MAIN_BUTTON_DEMANDES.Text = "Mes demandes";
            this.PRN_PN_MAIN_BUTTON_DEMANDES.UseVisualStyleBackColor = false;
            // 
            // PRN_PN_MAIN_BUTTON_DEC
            // 
            this.PRN_PN_MAIN_BUTTON_DEC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_MAIN_BUTTON_DEC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.PRN_PN_MAIN_BUTTON_DEC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRN_PN_MAIN_BUTTON_DEC.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold);
            this.PRN_PN_MAIN_BUTTON_DEC.ForeColor = System.Drawing.Color.White;
            this.PRN_PN_MAIN_BUTTON_DEC.Location = new System.Drawing.Point(333, 427);
            this.PRN_PN_MAIN_BUTTON_DEC.Name = "PRN_PN_MAIN_BUTTON_DEC";
            this.PRN_PN_MAIN_BUTTON_DEC.Size = new System.Drawing.Size(210, 90);
            this.PRN_PN_MAIN_BUTTON_DEC.TabIndex = 4;
            this.PRN_PN_MAIN_BUTTON_DEC.Text = "Déconexion";
            this.PRN_PN_MAIN_BUTTON_DEC.UseVisualStyleBackColor = false;
            this.PRN_PN_MAIN_BUTTON_DEC.Click += new System.EventHandler(this.button4_Click);
            // 
            // PRN_PN_LOC_MAIN
            // 
            this.PRN_PN_LOC_MAIN.BackColor = System.Drawing.Color.White;
            this.PRN_PN_LOC_MAIN.Controls.Add(this.PRN_PN_MAIN_BUTTON_DEMANDES);
            this.PRN_PN_LOC_MAIN.Controls.Add(this.PRN_PN_MAIN_BUTTON_DOSSIER);
            this.PRN_PN_LOC_MAIN.Controls.Add(this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT);
            this.PRN_PN_LOC_MAIN.Controls.Add(this.UserTest);
            this.PRN_PN_LOC_MAIN.Controls.Add(this.PRN_PN_MAIN_BUTTON_DEC);
            this.PRN_PN_LOC_MAIN.Controls.Add(this.PRN_PN_MAIN_BUTTON_LOGEMENTS);
            this.PRN_PN_LOC_MAIN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PRN_PN_LOC_MAIN.Location = new System.Drawing.Point(0, 0);
            this.PRN_PN_LOC_MAIN.Name = "PRN_PN_LOC_MAIN";
            this.PRN_PN_LOC_MAIN.Size = new System.Drawing.Size(857, 594);
            this.PRN_PN_LOC_MAIN.TabIndex = 5;
            // 
            // PRN_PN_MAIN_BUTTON_MON_LOGEMENT
            // 
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(224)))));
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Font = new System.Drawing.Font("Bahnschrift", 13.8F, System.Drawing.FontStyle.Bold);
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.ForeColor = System.Drawing.Color.White;
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Location = new System.Drawing.Point(333, 233);
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Name = "PRN_PN_MAIN_BUTTON_MON_LOGEMENT";
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Size = new System.Drawing.Size(210, 90);
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.TabIndex = 5;
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Text = "Voir mon logement";
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.UseVisualStyleBackColor = false;
            this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT.Click += new System.EventHandler(this.PRN_PN_MAIN_BUTTON_MON_LOGEMENT_Click);
            // 
            // PRN_PN_LOC_LOGEMENT
            // 
            this.PRN_PN_LOC_LOGEMENT.Controls.Add(this.button1);
            this.PRN_PN_LOC_LOGEMENT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PRN_PN_LOC_LOGEMENT.Location = new System.Drawing.Point(0, 0);
            this.PRN_PN_LOC_LOGEMENT.Name = "PRN_PN_LOC_LOGEMENT";
            this.PRN_PN_LOC_LOGEMENT.Size = new System.Drawing.Size(857, 594);
            this.PRN_PN_LOC_LOGEMENT.TabIndex = 5;
            this.PRN_PN_LOC_LOGEMENT.Paint += new System.Windows.Forms.PaintEventHandler(this.PRN_PN_LOC_LOGEMENT_Paint);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "Retour";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PRN_PN_LOC_MON_LOG
            // 
            this.PRN_PN_LOC_MON_LOG.Controls.Add(this.PRN_PN_LOC_MON_LOG_PIC1);
            this.PRN_PN_LOC_MON_LOG.Controls.Add(this.button2);
            this.PRN_PN_LOC_MON_LOG.Controls.Add(this.PRN_PN_LOC_MON_L_Lab3);
            this.PRN_PN_LOC_MON_LOG.Controls.Add(this.PRN_PN_LOC_MON_L_Lab2);
            this.PRN_PN_LOC_MON_LOG.Controls.Add(this.PRN_PN_LOC_MON_L_Lab1);
            this.PRN_PN_LOC_MON_LOG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PRN_PN_LOC_MON_LOG.Location = new System.Drawing.Point(0, 0);
            this.PRN_PN_LOC_MON_LOG.Name = "PRN_PN_LOC_MON_LOG";
            this.PRN_PN_LOC_MON_LOG.Size = new System.Drawing.Size(857, 594);
            this.PRN_PN_LOC_MON_LOG.TabIndex = 6;
            // 
            // PRN_PN_LOC_MON_LOG_PIC1
            // 
            this.PRN_PN_LOC_MON_LOG_PIC1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_LOC_MON_LOG_PIC1.ImageLocation = "";
            this.PRN_PN_LOC_MON_LOG_PIC1.Location = new System.Drawing.Point(545, 161);
            this.PRN_PN_LOC_MON_LOG_PIC1.Name = "PRN_PN_LOC_MON_LOG_PIC1";
            this.PRN_PN_LOC_MON_LOG_PIC1.Size = new System.Drawing.Size(300, 300);
            this.PRN_PN_LOC_MON_LOG_PIC1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PRN_PN_LOC_MON_LOG_PIC1.TabIndex = 1;
            this.PRN_PN_LOC_MON_LOG_PIC1.TabStop = false;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.Location = new System.Drawing.Point(26, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 39);
            this.button2.TabIndex = 2;
            this.button2.Text = "Retour";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // PRN_PN_LOC_MON_L_Lab3
            // 
            this.PRN_PN_LOC_MON_L_Lab3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_LOC_MON_L_Lab3.AutoSize = true;
            this.PRN_PN_LOC_MON_L_Lab3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRN_PN_LOC_MON_L_Lab3.Location = new System.Drawing.Point(19, 197);
            this.PRN_PN_LOC_MON_L_Lab3.Name = "PRN_PN_LOC_MON_L_Lab3";
            this.PRN_PN_LOC_MON_L_Lab3.Size = new System.Drawing.Size(133, 38);
            this.PRN_PN_LOC_MON_L_Lab3.TabIndex = 0;
            this.PRN_PN_LOC_MON_L_Lab3.Text = "Prix loc";
            // 
            // PRN_PN_LOC_MON_L_Lab2
            // 
            this.PRN_PN_LOC_MON_L_Lab2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_LOC_MON_L_Lab2.AutoSize = true;
            this.PRN_PN_LOC_MON_L_Lab2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRN_PN_LOC_MON_L_Lab2.Location = new System.Drawing.Point(19, 271);
            this.PRN_PN_LOC_MON_L_Lab2.Name = "PRN_PN_LOC_MON_L_Lab2";
            this.PRN_PN_LOC_MON_L_Lab2.Size = new System.Drawing.Size(202, 38);
            this.PRN_PN_LOC_MON_L_Lab2.TabIndex = 0;
            this.PRN_PN_LOC_MON_L_Lab2.Text = "Type appart";
            // 
            // PRN_PN_LOC_MON_L_Lab1
            // 
            this.PRN_PN_LOC_MON_L_Lab1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PRN_PN_LOC_MON_L_Lab1.AutoSize = true;
            this.PRN_PN_LOC_MON_L_Lab1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PRN_PN_LOC_MON_L_Lab1.Location = new System.Drawing.Point(12, 123);
            this.PRN_PN_LOC_MON_L_Lab1.Name = "PRN_PN_LOC_MON_L_Lab1";
            this.PRN_PN_LOC_MON_L_Lab1.Size = new System.Drawing.Size(257, 38);
            this.PRN_PN_LOC_MON_L_Lab1.TabIndex = 0;
            this.PRN_PN_LOC_MON_L_Lab1.Text = "Adresse Appart";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 39);
            this.button3.TabIndex = 1;
            this.button3.Text = "Retour";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nom : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mail : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Prénom : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 299);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "Code postal :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "Adresse : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ville :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 409);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 24);
            this.label7.TabIndex = 2;
            this.label7.Text = "Téléphone :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(26, 461);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "Date de naissance :";
            this.label8.Click += new System.EventHandler(this.label7_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(463, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 487);
            this.panel1.TabIndex = 3;
            // 
            // PRN_PN_LOC_DOSSIER_T1
            // 
            this.PRN_PN_LOC_DOSSIER_T1.Location = new System.Drawing.Point(90, 72);
            this.PRN_PN_LOC_DOSSIER_T1.Name = "PRN_PN_LOC_DOSSIER_T1";
            this.PRN_PN_LOC_DOSSIER_T1.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T1.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T2
            // 
            this.PRN_PN_LOC_DOSSIER_T2.Location = new System.Drawing.Point(117, 127);
            this.PRN_PN_LOC_DOSSIER_T2.Name = "PRN_PN_LOC_DOSSIER_T2";
            this.PRN_PN_LOC_DOSSIER_T2.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T2.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T5
            // 
            this.PRN_PN_LOC_DOSSIER_T5.Location = new System.Drawing.Point(148, 303);
            this.PRN_PN_LOC_DOSSIER_T5.Name = "PRN_PN_LOC_DOSSIER_T5";
            this.PRN_PN_LOC_DOSSIER_T5.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T5.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T7
            // 
            this.PRN_PN_LOC_DOSSIER_T7.Location = new System.Drawing.Point(130, 413);
            this.PRN_PN_LOC_DOSSIER_T7.Name = "PRN_PN_LOC_DOSSIER_T7";
            this.PRN_PN_LOC_DOSSIER_T7.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T7.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T3
            // 
            this.PRN_PN_LOC_DOSSIER_T3.Location = new System.Drawing.Point(90, 177);
            this.PRN_PN_LOC_DOSSIER_T3.Name = "PRN_PN_LOC_DOSSIER_T3";
            this.PRN_PN_LOC_DOSSIER_T3.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T3.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T4
            // 
            this.PRN_PN_LOC_DOSSIER_T4.Location = new System.Drawing.Point(117, 237);
            this.PRN_PN_LOC_DOSSIER_T4.Name = "PRN_PN_LOC_DOSSIER_T4";
            this.PRN_PN_LOC_DOSSIER_T4.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T4.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_T6
            // 
            this.PRN_PN_LOC_DOSSIER_T6.Location = new System.Drawing.Point(90, 360);
            this.PRN_PN_LOC_DOSSIER_T6.Name = "PRN_PN_LOC_DOSSIER_T6";
            this.PRN_PN_LOC_DOSSIER_T6.Size = new System.Drawing.Size(300, 22);
            this.PRN_PN_LOC_DOSSIER_T6.TabIndex = 4;
            // 
            // PRN_PN_LOC_DOSSIER_DATE1
            // 
            this.PRN_PN_LOC_DOSSIER_DATE1.Location = new System.Drawing.Point(217, 462);
            this.PRN_PN_LOC_DOSSIER_DATE1.Name = "PRN_PN_LOC_DOSSIER_DATE1";
            this.PRN_PN_LOC_DOSSIER_DATE1.Size = new System.Drawing.Size(240, 22);
            this.PRN_PN_LOC_DOSSIER_DATE1.TabIndex = 5;
            // 
            // PRN_PN_LOC_DOSSIER
            // 
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PictureBox_Id_CARD);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_B_SUB);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.BUTTON_ID_CARD);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_DATE1);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T6);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T4);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T3);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T7);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T5);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T2);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.PRN_PN_LOC_DOSSIER_T1);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.panel1);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label8);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label7);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label6);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label4);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label5);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label2);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label3);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.label1);
            this.PRN_PN_LOC_DOSSIER.Controls.Add(this.button3);
            this.PRN_PN_LOC_DOSSIER.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PRN_PN_LOC_DOSSIER.Location = new System.Drawing.Point(0, 0);
            this.PRN_PN_LOC_DOSSIER.Name = "PRN_PN_LOC_DOSSIER";
            this.PRN_PN_LOC_DOSSIER.Size = new System.Drawing.Size(857, 594);
            this.PRN_PN_LOC_DOSSIER.TabIndex = 6;
            // 
            // BUTTON_ID_CARD
            // 
            this.BUTTON_ID_CARD.Location = new System.Drawing.Point(491, 68);
            this.BUTTON_ID_CARD.Name = "BUTTON_ID_CARD";
            this.BUTTON_ID_CARD.Size = new System.Drawing.Size(145, 44);
            this.BUTTON_ID_CARD.TabIndex = 6;
            this.BUTTON_ID_CARD.Text = "ID CARD";
            this.BUTTON_ID_CARD.UseVisualStyleBackColor = true;
            this.BUTTON_ID_CARD.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // PictureBox_Id_CARD
            // 
            this.PictureBox_Id_CARD.Location = new System.Drawing.Point(663, 49);
            this.PictureBox_Id_CARD.Name = "PictureBox_Id_CARD";
            this.PictureBox_Id_CARD.Size = new System.Drawing.Size(145, 90);
            this.PictureBox_Id_CARD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox_Id_CARD.TabIndex = 7;
            this.PictureBox_Id_CARD.TabStop = false;
            // 
            // PRN_PN_LOC_DOSSIER_B_SUB
            // 
            this.PRN_PN_LOC_DOSSIER_B_SUB.Location = new System.Drawing.Point(584, 473);
            this.PRN_PN_LOC_DOSSIER_B_SUB.Name = "PRN_PN_LOC_DOSSIER_B_SUB";
            this.PRN_PN_LOC_DOSSIER_B_SUB.Size = new System.Drawing.Size(145, 44);
            this.PRN_PN_LOC_DOSSIER_B_SUB.TabIndex = 6;
            this.PRN_PN_LOC_DOSSIER_B_SUB.Text = "Valider ";
            this.PRN_PN_LOC_DOSSIER_B_SUB.UseVisualStyleBackColor = true;
            this.PRN_PN_LOC_DOSSIER_B_SUB.Click += new System.EventHandler(this.PRN_PN_LOC_DOSSIER_B_SUB_Click);
            // 
            // userType1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 594);
            this.Controls.Add(this.PRN_PN_LOC_DOSSIER);
            this.Controls.Add(this.PRN_PN_LOC_MAIN);
            this.Controls.Add(this.PRN_PN_LOC_MON_LOG);
            this.Controls.Add(this.PRN_PN_LOC_LOGEMENT);
            this.Name = "userType1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locataire";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.PRN_PN_LOC_MAIN.ResumeLayout(false);
            this.PRN_PN_LOC_MAIN.PerformLayout();
            this.PRN_PN_LOC_LOGEMENT.ResumeLayout(false);
            this.PRN_PN_LOC_MON_LOG.ResumeLayout(false);
            this.PRN_PN_LOC_MON_LOG.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PRN_PN_LOC_MON_LOG_PIC1)).EndInit();
            this.PRN_PN_LOC_DOSSIER.ResumeLayout(false);
            this.PRN_PN_LOC_DOSSIER.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox_Id_CARD)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label UserTest;
        private System.Windows.Forms.Button PRN_PN_MAIN_BUTTON_DOSSIER;
        private System.Windows.Forms.Button PRN_PN_MAIN_BUTTON_LOGEMENTS;
        private System.Windows.Forms.Button PRN_PN_MAIN_BUTTON_DEMANDES;
        private System.Windows.Forms.Button PRN_PN_MAIN_BUTTON_DEC;
        private System.Windows.Forms.Panel PRN_PN_LOC_MAIN;
        private System.Windows.Forms.Panel PRN_PN_LOC_LOGEMENT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button PRN_PN_MAIN_BUTTON_MON_LOGEMENT;
        private System.Windows.Forms.Panel PRN_PN_LOC_MON_LOG;
        private System.Windows.Forms.Label PRN_PN_LOC_MON_L_Lab1;
        private System.Windows.Forms.Label PRN_PN_LOC_MON_L_Lab3;
        private System.Windows.Forms.Label PRN_PN_LOC_MON_L_Lab2;
        private System.Windows.Forms.PictureBox PRN_PN_LOC_MON_LOG_PIC1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T1;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T2;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T5;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T7;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T3;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T4;
        private System.Windows.Forms.TextBox PRN_PN_LOC_DOSSIER_T6;
        private System.Windows.Forms.DateTimePicker PRN_PN_LOC_DOSSIER_DATE1;
        private System.Windows.Forms.Panel PRN_PN_LOC_DOSSIER;
        private System.Windows.Forms.Button BUTTON_ID_CARD;
        private System.Windows.Forms.PictureBox PictureBox_Id_CARD;
        private System.Windows.Forms.Button PRN_PN_LOC_DOSSIER_B_SUB;
    }
}